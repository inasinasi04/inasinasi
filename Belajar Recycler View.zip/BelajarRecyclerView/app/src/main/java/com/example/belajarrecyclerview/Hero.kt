package com.example.belajarrecyclerview
import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class Hero(
    val name: String,
    val path: String,
    val timestamp: String,
    val faction: String,
    val description: String,
    val photo: Int
) : Parcelable
