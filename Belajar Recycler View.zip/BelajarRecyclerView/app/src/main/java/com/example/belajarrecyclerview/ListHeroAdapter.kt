package com.example.belajarrecyclerview

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.belajarrecyclerview.databinding.ItemRowHeroBinding

class ListHeroAdapter(private val listHero: ArrayList<Hero>) : RecyclerView.Adapter<ListHeroAdapter.ListViewHolder>() {

    private lateinit var onItemClickCallback: OnItemClickCallback

    // Callback untuk item yang diklik
    fun setOnItemClickCallback(onItemClickCallback: OnItemClickCallback) {
        this.onItemClickCallback = onItemClickCallback
    }

    interface OnItemClickCallback {
        fun onItemClicked(data: Hero)
    }

    // Memanggil layout melalui binding
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ListViewHolder {
        val binding = ItemRowHeroBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ListViewHolder(binding)
    }

    // Mengikat data ke view dengan menggunakan binding
    override fun onBindViewHolder(holder: ListViewHolder, position: Int) {
        val hero = listHero[position]
        holder.bind(hero)
    }

    override fun getItemCount(): Int = listHero.size

    // ViewHolder dengan menggunakan View Binding
    inner class ListViewHolder(private val binding: ItemRowHeroBinding) : RecyclerView.ViewHolder(binding.root) {

        // Bind data ke views
        fun bind(hero: Hero) {
            binding.imgItemPhoto.setImageResource(hero.photo)
            binding.tvItemName.text = hero.name
            binding.tvItemTimestamp.text = hero.timestamp
            binding.tvItemDescription.text = hero.description

            // Set listener untuk item view
            itemView.setOnClickListener {
                onItemClickCallback.onItemClicked(hero)
            }
        }
    }
}
