package com.example.belajarrecyclerview

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.drawable.BitmapDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.GridLayoutManager
import com.example.belajarrecyclerview.databinding.ActivityDetailBinding
import java.io.File
import java.io.FileOutputStream

class DetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDetailBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Initialize View Binding
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Set judul toolbar
        supportActionBar?.title = "Detail Barang"

        // Menampilkan tombol back di Toolbar
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        // Ambil data Parcelable dari Intent
        val data = intent.getParcelableExtra<Hero>("DATA")

        // Periksa apakah data tidak null
        if (data != null) {
            // Set data ke view menggunakan View Binding
            binding.detailImgItemPhoto.setImageResource(data.photo)
            binding.detailTvItemName.text = data.name
            binding.detailTvItemPath.text = data.path
            binding.detailTvItemTimestamp.text = data.timestamp
            binding.detailTvItemFaction.text = data.faction
            binding.detailTvItemDescription.text = data.description
        }

        // Menangani window insets dengan ViewCompat
        ViewCompat.setOnApplyWindowInsetsListener(binding.detailCardView) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    // Membuat AppBar
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_detail, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            // Jika Tombol Back Dipencet, Kembali Ke Halaman Sebelumnya
            android.R.id.home -> {
                onBackPressed()
                true
            }

            R.id.action_share -> {
                // Ambil data dari View Binding
                val itemName = binding.detailTvItemName.text.toString()
                val itemPath = binding.detailTvItemPath.text.toString()
                val itemFaction = binding.detailTvItemFaction.text.toString()
                val itemDescription = binding.detailTvItemDescription.text.toString()
                val shareText = """
                Lihat Pahlawanku:
                
                Nama  = $itemName
                Path  = $itemPath
                Faksi = $itemFaction
                
                Biografi = $itemDescription
                """.trimIndent()

                // Simpan gambar ke cache directory
                val drawable = binding.detailImgItemPhoto.drawable
                val bitmap = (drawable as BitmapDrawable).bitmap
                val cachePath = File(cacheDir, "images")
                cachePath.mkdirs()
                val file = File(cachePath, "shared_image.png")
                FileOutputStream(file).use { stream ->
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)
                }

                // Dapatkan URI gambar menggunakan FileProvider
                val imageUri: Uri = FileProvider.getUriForFile(
                    this,
                    "${applicationContext.packageName}.provider",
                    file
                )

                // Intent untuk share gambar dan teks
                val shareIntent = Intent().apply {
                    action = Intent.ACTION_SEND
                    type = "image/*"
                    putExtra(Intent.EXTRA_STREAM, imageUri)
                    putExtra(Intent.EXTRA_TEXT, shareText)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) // Berikan izin akses URI
                }

                // Tampilkan chooser untuk aplikasi yang mendukung ACTION_SEND
                startActivity(Intent.createChooser(shareIntent, "Bagikan ke"))
                true
            }

            else -> super.onOptionsItemSelected(item)
        }
    }
}
