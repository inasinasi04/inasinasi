package com.example.belajarrecyclerview

import android.content.Intent
import android.content.res.Configuration
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.belajarrecyclerview.databinding.FragmentHomeBinding

class HomeFragment : Fragment(R.layout.fragment_home) {

    private lateinit var binding: FragmentHomeBinding
    private val list = ArrayList<Hero>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Initialize View Binding
        binding = FragmentHomeBinding.inflate(inflater, container, false)

        // Set up RecyclerView
        binding.rvHeroes.setHasFixedSize(true)
        list.addAll(getListHeroes())
        showRecyclerList()

        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Mengakses ActionBar hanya jika activity adalah AppCompatActivity
        (activity as? AppCompatActivity)?.supportActionBar?.apply {
            title = "Dicoding Submission"
            setBackgroundDrawable(ColorDrawable(ContextCompat.getColor(requireContext(), R.color.appbarColor))) // Set warna appbar
        }

        // Memberitahu bahwa fragment ini memiliki menu
        setHasOptionsMenu(true)
    }

    private fun getListHeroes(): ArrayList<Hero> {
        val dataName = resources.getStringArray(R.array.data_name)
        val dataPath = resources.getStringArray(R.array.data_path)
        val dataTimestamp = resources.getStringArray(R.array.data_timestamp)
        val dataFaction = resources.getStringArray(R.array.data_faction)
        val dataDescription = resources.getStringArray(R.array.data_description)
        val dataPhoto = resources.obtainTypedArray(R.array.data_photo)
        val listHero = ArrayList<Hero>()
        for (i in dataName.indices) {
            val hero = Hero(dataName[i], dataPath[i], dataTimestamp[i], dataFaction[i], dataDescription[i], dataPhoto.getResourceId(i, -1))
            listHero.add(hero)
        }
        return listHero
    }

    private fun showRecyclerList() {
        // Set the layout manager based on orientation
        if (resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            binding.rvHeroes.layoutManager = GridLayoutManager(activity, 2)
        } else {
            binding.rvHeroes.layoutManager = LinearLayoutManager(activity)
        }

        val listHeroAdapter = ListHeroAdapter(list)
        binding.rvHeroes.adapter = listHeroAdapter

        // Handle item click callback
        listHeroAdapter.setOnItemClickCallback(object : ListHeroAdapter.OnItemClickCallback {
            override fun onItemClicked(data: Hero) {
                val intentToDetail = Intent(activity, DetailActivity::class.java)
                intentToDetail.putExtra("DATA", data)
                startActivity(intentToDetail)
            }
        })
    }

    // Show a Toast when a hero is selected
    private fun showSelectedHero(hero: Hero) {
        Toast.makeText(activity, "Kamu memilih " + hero.name, Toast.LENGTH_SHORT).show()
    }

    // Create the app bar (menu) if needed
    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.menu_home, menu)
        super.onCreateOptionsMenu(menu, inflater)
    }

    // Handle menu item selection
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.action_list -> {
                binding.rvHeroes.layoutManager = LinearLayoutManager(activity)
            }
            R.id.action_grid -> {
                binding.rvHeroes.layoutManager = GridLayoutManager(activity, 2)
            }
        }
        return super.onOptionsItemSelected(item)
    }
}
