package com.example.belajarrecyclerview

import android.content.Intent
import android.os.Bundle
import android.view.Window
import android.view.animation.AnimationUtils
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.example.belajarrecyclerview.databinding.ActivitySplashBinding
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class SplashActivity : AppCompatActivity() {

    // Mendeklarasikan ViewBinding
    private lateinit var binding: ActivitySplashBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Memastikan requestWindowFeature dipanggil sebelum setContentView()
        requestWindowFeature(Window.FEATURE_NO_TITLE)  // Menghilangkan title bar
        window.decorView.systemUiVisibility = android.view.View.SYSTEM_UI_FLAG_FULLSCREEN

        // Menyembunyikan ActionBar (AppBar)
        supportActionBar?.hide()

        // Menggunakan ViewBinding untuk mengakses komponen UI
        binding = ActivitySplashBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Menambahkan animasi untuk logo
        val animation = AnimationUtils.loadAnimation(this, R.anim.fade_in)
        binding.splashImage.startAnimation(animation)

        // Memuat gambar menggunakan Glide dan membuatnya bundar
        Glide.with(this)
            .load(R.drawable.app_logo)  // Ganti dengan URL jika gambar dari internet
            .circleCrop()  // Membuat gambar bundar
            .into(binding.splashImage)

        // Delay sebelum berpindah ke MainActivity
        GlobalScope.launch {
            delay(3000) // Delay selama 3 detik
            startActivity(Intent(this@SplashActivity, MainActivity::class.java))
            finish() // Menutup SplashActivity agar tidak bisa kembali
        }
    }
}
